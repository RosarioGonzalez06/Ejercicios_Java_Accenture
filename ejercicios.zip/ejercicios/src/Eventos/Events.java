package Eventos;

public class Events {
    Integer id;
    String name;
    String type;
    Integer seatsAvailable;


    public Events(Integer id, String name, String type, Integer seatsAvailable) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.seatsAvailable = seatsAvailable;
    }

    @Override
    public String toString() {
        return "ID: " + id+ " name: " + name+ " type: " + type+ " seatsAvailable: " + seatsAvailable;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getSeatsAvailable() {
        return seatsAvailable;
    }

    public void setSeatsAvailable(Integer seatsAvailable) {
        this.seatsAvailable = seatsAvailable;
    }
}

