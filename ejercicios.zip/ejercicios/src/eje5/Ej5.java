package eje5;

import Eventos.Events;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class Ej5 {
    public static void main(String[] args) {
        ArrayList<Events> eventos= new ArrayList<>();

        eventos.add(new Events(1,"Event 1", "musical", 3));
        eventos.add(new Events(2,"Event 2", "sport", 5));
        eventos.add(new Events(3,"Event 3", "sport", 10));
        eventos.add(new Events(4,"Event 4", "cultural", 34));
        eventos.add(new Events(5,"Event 5", "sport", 56));

        ArrayList<Events> sports = new ArrayList<>();
        for (Events e : eventos) {
            if (e.getType().equals("sport")) {
                sports.add(e);
            }
        }

        Collections.sort(sports,new Comparator<Events>() {
            public int compare(Events o1, Events o2) {
                return o2.getName().compareTo(o1.getName());
            }
        });

        for (Events s : sports) {
            System.out.println(s.getId());
        }
    }
}
