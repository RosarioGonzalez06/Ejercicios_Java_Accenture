package eje4;

import Eventos.Events;

import java.util.ArrayList;

public class Ej4 {
    public static void main(String[] args) {
        ArrayList<Events> eventos = new ArrayList<>();

        eventos.add(new Events(1, "Event 1", "musical", 3));
        eventos.add(new Events(2, "Event 2", "sport", 5));
        eventos.add(new Events(3, "Event 3", "sport", 10));
        eventos.add(new Events(4, "Event 4", "cultural", 34));
        eventos.add(new Events(5, "Event 5", "sport", 56));

        ArrayList<Events> sports = new ArrayList<>();
    for (Events e : eventos) {
            if (e.getType().equals("sport")) {
                sports.add(e);
            }
        }
        for (Events s : sports) {
            System.out.println(s.getId());
        }
    }
}
